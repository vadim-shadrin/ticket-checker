import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Инициализация DI и других библиотек здесь
    }
}